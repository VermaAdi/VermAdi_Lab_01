package Lab;

/**
 * Name: Aditya Verma
 * Date: January 16th, 2022
 * Description: Lab 01 "HelloWorld Lab" Submission for CS321.
 */
public class HelloWorld {

    /**
     * Prints out "\nMy Hello World Program for Lab 01 for CS 321 at Bishop's University!\n"
     * @param args A string array containing the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("***********************************************************************");
        System.out.println("\nMy Hello World Program for Lab 01 for CS 321 at Bishop's University!\n");
        System.out.println("***********************************************************************");
    }
}
